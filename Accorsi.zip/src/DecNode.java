
public interface DecNode {

	Node getSymType();
	
}
